(() => {
  'use strict';
  const root=document.documentElement, media=matchMedia('(prefers-color-scheme: dark)');
  const data=JSON.parse(document.querySelector('#screen-data').textContent);
  const ids=Object.keys(data), toast=document.querySelector('.toast');
  let mode=new URLSearchParams(location.search).get('theme');
  if(!['light','dark','system'].includes(mode)){try{mode=localStorage.getItem('sukoon-proposal-theme')||'system'}catch{mode='system'}}
  if(!['light','dark','system'].includes(mode))mode='system';
  let timer,focusId,focusPhone,placeholder,confirmAction;
  const focus=document.querySelector('.focus-dialog'),confirm=document.querySelector('.confirm-dialog');
  const renderedState=Object.fromEntries(ids.map(id=>[id,'default']));
  const drafts=new Map();
  function notify(msg){toast.textContent=msg;toast.hidden=false;clearTimeout(timer);timer=setTimeout(()=>toast.hidden=true,4500)}
  function sync(){
    root.dataset.theme=mode==='system'?(media.matches?'dark':'light'):mode;
    root.dataset.mode=mode;
    document.querySelectorAll('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mode===mode)));
    document.querySelectorAll('a[href$="design-map.html"],a[href*="design-map.html?"],a[href$="../../index.html"],a[href*="../../index.html?"]').forEach(a=>{const u=new URL(a.href);u.searchParams.set('theme',mode);a.href=u.href});
  }
  media.addEventListener('change',()=>{if(mode==='system')sync()});sync();
  function phone(id){return focusId===id?focusPhone:document.querySelector(`#${id} .phone`)}
  function stash(id){const p=phone(id);drafts.set(id+'|'+renderedState[id],{html:p.querySelector('main').innerHTML,values:[...p.querySelectorAll('main input,main select')].map(el=>({value:el.value,checked:el.checked})),scroll:p.querySelector('main').scrollTop,footer:p.querySelector('.phone-footer').innerHTML})}
  function state(id,name){
    const previous=renderedState[id];stash(id);const previousDraft=drafts.get(id+'|'+previous);const p=phone(id);renderedState[id]=name;
    const saved=drafts.get(id+'|'+name);const retained=((name==='server-error'&&previous==='default')||(name==='default'&&previous==='server-error'))?previousDraft:null;
    p.querySelector('main').innerHTML=saved?.html||(name==='default'?data[id].content:data[id].variants[name])||data[id].content;
    p.querySelector('.phone-footer').innerHTML=saved?.footer||(name==='default'||(name==='server-error'&&['S21','S22','S23','S27','S30','S31','S32','S35','S39'].includes(id))?data[id].footer:'');
    const restoreDraft=retained||saved;if(restoreDraft){p.querySelectorAll('main input,main select').forEach((el,i)=>{if(restoreDraft.values[i]){el.value=restoreDraft.values[i].value;el.checked=restoreDraft.values[i].checked}});p.querySelector('main').scrollTop=restoreDraft.scroll}
    document.querySelector(`[data-state="${id}"]`).value=name;
  }
  function restore(){if(focusPhone&&placeholder){placeholder.replaceWith(focusPhone)}focusPhone=null;placeholder=null;focusId=null}
  function show(id){
    if(!data[id]){const u=new URL('../../index.html',location.href);u.searchParams.set('theme',mode);u.hash=id;location.href=u.href;return}
    if(focusPhone)restore();
    const p=document.querySelector(`#${id} .phone`);placeholder=document.createElement('div');placeholder.style.height=p.offsetHeight+'px';p.replaceWith(placeholder);focusPhone=p;focusId=id;
    document.querySelector('.focus-body').replaceChildren(p);
    document.querySelector('[data-focus-title]').textContent=document.querySelector(`#${id} .screen-head h2`).textContent;
    document.querySelector('[data-prev]').disabled=ids.indexOf(id)===0;document.querySelector('[data-next]').disabled=ids.indexOf(id)===ids.length-1;
    if(!focus.open)focus.showModal();
  }
  focus.addEventListener('close',restore);
  function ask(title,copy,fn){document.querySelector('[data-confirm-title]').textContent=title;document.querySelector('[data-confirm-copy]').textContent=copy;confirmAction=fn;confirm.showModal()}
  confirm.addEventListener('close',()=>confirmAction=null);
  const next={
    'my-reviews':'تقييماتي','account-summary':'ملخص حساب المستأجر','subscriptions':'الاشتراكات','invoices':'الفواتير','chat-policy':'مراجعات سياسة المحادثات','legal':'الشروط وسياسة الخصوصية','business-policies':'سياسات الاستخدام','guide-settings':'إرشادات التجربة','contract-document':'مستند العقد','my-housing':'مسكني','support-new':'إنشاء طلب دعم','support-tickets':'طلبات الدعم','feedback':'اقتراح تحسين'
  };
  document.addEventListener('change',ev=>{
    const el=ev.target;
    if(el.matches('[data-state]'))state(el.dataset.state,el.value);
    if(el.id==='group-filter')document.querySelectorAll('.sprint-screen').forEach(s=>s.hidden=el.value!=='all'&&s.dataset.group!==el.value);
    if(el.name==='ack'){const p=el.closest('.phone');p.querySelector('[data-action="delete-account"]').disabled=!el.checked}
  });
  document.addEventListener('input',ev=>{
    if(ev.target.matches('input[name=password],input[name=confirm]'))ev.target.closest('form')?.elements.confirm?.setCustomValidity('');
    if(ev.target.matches('.otp-row input')){ev.target.value=ev.target.value.replace(/[^0-9٠-٩]/g,'').slice(0,1);if(ev.target.value)ev.target.nextElementSibling?.focus()}
    if(ev.target.matches('[data-faq-search]')){const p=ev.target.closest('.phone'),q=ev.target.value.trim();let count=0;p.querySelectorAll('.faq').forEach(d=>{d.hidden=!d.textContent.includes(q);if(!d.hidden)count++});p.querySelector('[data-faq-empty]').hidden=count>0}
  });
  function validPassword(f){const pw=f.elements.password.value,confirmation=f.elements.confirm;confirmation.setCustomValidity('');if(pw!==confirmation.value)confirmation.setCustomValidity('كلمتا المرور غير متطابقتين.');else if(!pw.trim())confirmation.setCustomValidity('لا تستخدم مسافات فقط.');return f.reportValidity()}
  document.addEventListener('submit',ev=>{
    if(!ev.target.matches('[data-form]'))return;ev.preventDefault();const f=ev.target,p=f.closest('.phone'),id=p.dataset.screen;
    if(['register','password'].includes(f.dataset.form)&&!validPassword(f))return;
    switch(f.dataset.form){
      case 'register':notify('معاينة: التسجيل ينتقل لتأكيد البريد ثم تسجيل الدخول.');ask('متابعة لتأكيد البريد؟','سنعرض شاشة الرمز الأصلية. لم يتم إنشاء حساب أو إرسال بريد.',()=>show('S03'));break;
      case 'recovery':{
        const address=f.elements.email.value;const box=document.createElement('div');box.className='panel';const title=document.createElement('h3');title.textContent='راجع بريدك.';const text=document.createElement('p');text.textContent='معاينة فقط: رابط الاستعادة إلى '+address.slice(0,2)+'****@'+address.split('@')[1];box.append(title,text);p.querySelector('main').replaceChildren(box);const b=document.createElement('button');b.className='secondary wide';b.dataset.action='reset-state';b.textContent='تغيير البريد';box.append(b);notify('حالة الإرسال توضيحية. لم نرسل بريدًا.');break}
      case 'profile':notify('معاينة: تُحفظ البيانات بعد نجاح استجابة الخادم.');break;
      case 'password':ask('تغيير كلمة المرور؟','بعد النجاح ينهي التطبيق الجلسة ويطلب تسجيل الدخول. المعاينة لن تغيّر أي بيانات.',()=>show('S02'));break;
      case 'email-old':state(id,'enter-new');break;
      case 'new-email':state(id,'verify-new');break;
      case 'email-new':state(id,'complete');break;
    }
  });
  document.addEventListener('click',ev=>{
    const b=ev.target.closest('button');if(!b)return;
    if(b.dataset.mode){mode=b.dataset.mode;try{localStorage.setItem('sukoon-proposal-theme',mode)}catch{}sync();return}
    if(b.dataset.focus){show(b.dataset.focus);return}
    if(b.hasAttribute('data-close')){focus.close();return}
    if(b.hasAttribute('data-prev')||b.hasAttribute('data-next')){show(ids[ids.indexOf(focusId)+(b.hasAttribute('data-next')?1:-1)]);return}
    if(b.dataset.go){show(b.dataset.go);return}
    if(b.hasAttribute('data-cancel')){confirm.close();return}
    if(b.hasAttribute('data-confirm')){const fn=confirmAction;confirm.close();fn?.();return}
    if(b.dataset.switch){const old=b.getAttribute('aria-checked');b.setAttribute('aria-checked',String(old!=='true'));notify('اختيار محلي للمعاينة. التطبيق يستعيد القيمة السابقة إذا فشل الحفظ.');return}
    const action=b.dataset.action,p=b.closest('.phone'),id=p?.dataset.screen;if(!action)return;
    if(next[action]){notify('الخطوة التالية في التطبيق: '+next[action]+'. مجدولة في خطة السبرنتات، ولم تُصمّم هنا.');return}
    if(action==='password'){const input=b.previousElementSibling;input.type=input.type==='password'?'text':'password';return}
    if(action==='reset-state'){drafts.delete(id+'|default');drafts.delete(id+'|'+renderedState[id]);renderedState[id]='default';p.querySelector('main').innerHTML=data[id].content;p.querySelector('.phone-footer').innerHTML=data[id].footer;document.querySelector(`[data-state="${id}"]`).value='default';return}
    if(action==='email-start'){state(id,'verify-old');return}
    if(action==='email-restart'){state(id,'default');return}
    if(action==='email-status'){notify('التطبيق يراجع حالة العملية على الخادم قبل إعادة البدء.');return}
    if(action==='resend'){notify('معاينة: إعادة الإرسال تخضع لموعد الخادم وحدود المحاولات.');return}
    if(action==='sample-upload'){b.classList.toggle('selected');b.querySelector('.upload-state').textContent=b.classList.contains('selected')?'✓':'＋';return}
    if(action==='submit-kyc'){
      const idValue=p.querySelector('[name=nationalId]')?.value||'';const selected=p.querySelectorAll('.upload-tile.selected').length;
      if(!/^[23][0-9]{13}$/.test(idValue)||selected!==3){p.querySelector('.inline-feedback').textContent='أدخل رقمًا قوميًّا من ١٤ رقمًا واختر العينات الثلاث. التحقق هنا مبسّط؛ التطبيق يتحقق من التاريخ والمستندات أيضًا.';return}
      ask('إرسال للمراجعة؟','انتقال لحالة انتظار توضيحية. لا تُرفع أي ملفات.',()=>show('S24'));return}
    if(action.startsWith('revoke-')||action==='compromised'){
      ask(b.textContent,'تأكيد محلي فقط. ينفّذ التطبيق الإجراء بعد نجاح الخادم؛ إنهاء الجلسة الحالية أو الكل يعيدك لتسجيل الدخول.',()=>{if(['revoke-current','revoke-all','compromised'].includes(action))show('S02');else {if(action==='revoke-session')b.closest('.panel').remove();else p.querySelectorAll('.session-card').forEach(el=>{if(!el.querySelector('.badge'))el.closest('.panel').remove()});notify('تم عرض نتيجة محلية توضيحية.')}});return}
    if(action==='delete-account'){ask('تأكيد حذف الحساب؟','هذه معاينة فقط. في التطبيق، يجب نجاح الحذف قبل إنهاء الجلسة.',()=>{notify('لم يُحذف حساب. تم عرض نهاية الرحلة التوضيحية.');show('S02')});return}
    if(action==='logout'){ask('تسجيل الخروج؟','عرض رحلة الخروج فقط. لم نتصل بحسابك.',()=>show('S02'));return}
    if(action==='read-all'){p.querySelectorAll('.unread-dot').forEach(el=>el.remove());b.textContent='كل الإشعارات مقروءة · معاينة';return}
    if(action==='notification-related'){show('S11');return}
    if(action==='language-confirm'){notify('تم اختيار '+(p.querySelector('[name=language]:checked').value==='ar'?'العربية':'English')+' للمعاينة. التنفيذ سيطبق اللغة والاتجاه على التطبيق.');return}
    if(action==='avatar'){notify('معاينة اختيار الصورة؛ لا تُفتح صورك أو تُرفع ملفات.');return}
    if(action==='device-settings'){notify('في التطبيق: فتح إعدادات إشعارات الجهاز.');return}
    if(action==='support-email'){notify('التطبيق يستخدم عنوان التواصل الصالح الذي يرسله الخادم.');return}
    notify('عنصر توضيحي مرتبط بسلوك التطبيق الحالي.');
  });
})();
