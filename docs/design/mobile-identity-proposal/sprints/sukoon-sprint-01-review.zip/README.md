# Mobile identity proposal — continuation sprints

Start with [Sprint 1 mockups](sprint-01/index.html). It is self-contained and works offline. Use Light, Dark or System, enlarge a screen, filter by group, or change an individual screen's review state.

[Full sprint plan](SPRINT-PLAN.md) · [Source inventory](screen-inventory.json) · [Sprint 1 behavior audit](sprint-01/AUDIT.md) · [Recorded browser checks](sprint-01/review-results.json)

The 20 original screens remain S01–S20. The current app source is the sibling `sokoun/apps/sokoun_app/lib`, replacing the old handoff's `mobile/` location. The inventory reconciles 304 screen/page source files: 20 originally covered, five flow hosts/components, and 279 remaining. Those are scheduled in 14 sprints: 13 of 20 screens, then 19. Sprint 1 delivers S21–S40; 259 screens remain planned. Later sprints need their own behavior/dependency audit before design work.

Only Sprint 1 is built. **Stop for the user's confirmation before starting Sprint 2.** Flutter production code, business behavior, shared tokens and the original proposal are unchanged.

Sprint 1 includes registration/recovery, identity documents/pending/approval, tenant profile, edit/settings/verification/privacy, password/email changes, sessions, language, deletion, contracts, notification inbox/detail/preferences, and help center. Source hashes, dependencies, behavior and required implementation states are recorded in its manifest and audit.

## Review artifacts

- `sprint-01/index.html`: 20 distinct primary mockups; both themes and System.
- `sprint-01/exports/S21-light.png` through `S40-dark.png`: 40 individual 720 × 1600 PNGs. Long forms and lists scroll in the HTML; PNGs show their initial viewport.
- `sprint-01/exports/light-sheet-1.png` through `dark-sheet-5.png`: ten four-screen presentation sheets.
- `sprint-01/exports/light-overview.png` and `dark-overview.png`: all-screen overviews.
- `sprint-01/screen-manifest.json` and `AUDIT.md`: current source and behavior contract. Required native states and separately rendered review variants are distinguished.

Every name, device, contract, notification and message is illustrative. There are no backend calls, real account changes, emails or uploads. Buttons for destinations outside this sprint identify their next app step. The English choice demonstrates selection; it does not claim a complete English mockup.

## Rebuild and verify

From `Sukoon-API`:

```sh
python3 docs/design/mobile-identity-proposal/sprints/build_sprints.py
PLAYWRIGHT_MODULE=/absolute/path/to/playwright CHROME_EXECUTABLE=/absolute/path/to/chrome node docs/design/mobile-identity-proposal/sprints/review_sprint.cjs
```

The generator requires the sibling `sokoun` checkout and the original proposal's embedded foundation. It writes only the sprint directory. The review script uses Playwright; set its package and Chromium executable paths for your device. It exports both themes and checks all rendered states, 360/390/768/1680px widths, theme/draft preservation, local forms and confirmations, source links, semantic token contrast, and absence of page errors or external requests. Browser checks do not replace native Flutter/device, text scaling or API integration testing.

## Approved visual reference

The user prefers the original S01–S20 visual style. [Design direction](DESIGN-DIRECTION.md) records that requirement. Sprint 1 now extends the original auth/status/utility/hub layouts directly and its manifest maps every new screen to its original visual references. This revision awaits user review; Sprint 2 remains unstarted.
