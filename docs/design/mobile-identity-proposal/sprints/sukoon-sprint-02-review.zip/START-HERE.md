# Sprint 2 review

Open `mobile-identity-proposal/sprints/sprint-02/index.html`. It works offline. The original and Sprint 1 review pages are also included for navigation. Flutter source links/rebuilding require the sibling checkout. Sprint 3 is not started.
